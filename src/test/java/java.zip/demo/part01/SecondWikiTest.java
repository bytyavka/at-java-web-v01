package demo.part01;

public class SecondWikiTest {

}
